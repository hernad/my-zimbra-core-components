package NetSNMP::agent::netsnmp_request_infoPtr;

# bogus file

1;
__END__

=head1 NAME

NetSNMP::agent::netsnmp_request_infoPtr - Perl extension for request information

=head1 SYNOPSIS

  see NetSNMP::agent documentation

=head1 AUTHOR

Please mail the net-snmp-users@lists.sourceforge.net mailing list for
help, questions or comments about this module.

Wes Hardaker, hardaker@users.sourceforge.net

=cut
