
package BerkeleyDB::Hash ;

# This file is only used for MLDBM

use BerkeleyDB ;

1 ;
